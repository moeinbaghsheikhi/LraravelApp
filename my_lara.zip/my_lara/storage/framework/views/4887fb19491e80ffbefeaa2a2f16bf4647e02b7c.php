<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>login</title>
</head>
<body>
<h1>Welcome to login page</h1>
</body>
</html>
<?php /**PATH /home/moein/Desktop/my_lara/resources/views/login.blade.php ENDPATH**/ ?>